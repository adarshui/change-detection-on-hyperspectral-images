from django.shortcuts import render


from django.http import HttpResponse
import mimetypes
import os

def serve_image(request, image_path):
    image_full_path = os.path.join('C:/Users/Hp/Desktop/adi 123/adi/GT/media/', image_path)
    if os.path.exists(image_full_path):
        with open(image_full_path, 'rb') as f:
            content_type = mimetypes.guess_type(image_full_path)[0]
            response = HttpResponse(f.read(), content_type=content_type)
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(image_full_path)
            print(response)
            return response
    else:
        return HttpResponse('Image not found', status=404)


def index(request):
    return render (request,'index.html')


from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import os
import base64
@csrf_exempt
def upload_files(request):
    if request.method == 'POST':
        old_image = request.FILES.get('old_image')
        new_image = request.FILES.get('new_image')
        gt_image = request.FILES.get('gt_image')

        if old_image and new_image and gt_image:
            # Define the base directory of your Django project
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

            # Check if the directory exists, if not, create it
            if not os.path.exists(base_dir):
                os.makedirs(base_dir)

            # Remove the .mt extension from the file names if it already exists
            # old_image_name = old_image.name.replace('.mat', '')
            # new_image_name = new_image.name.replace('.mat', '')
            # gt_image_name = gt_image.name.replace('.mat', '')

            # Save the files to the base directory with their original file names and the .mt extension

            old_image_name = "old_image"
            new_image_name = "new_image"
            gt_image_name = "gt_image"

            # Create directory if it doesn't exist
            mat_images_dir = os.path.join(base_dir, "mat_images")
            os.makedirs(mat_images_dir, exist_ok=True)

            # Delete existing files if they exist
            for filename in [f'{old_image_name}.mat', f'{new_image_name}.mat', f'{gt_image_name}.mat']:
                file_path = os.path.join(mat_images_dir, filename)
                if os.path.exists(file_path):
                    os.remove(file_path)

            # Construct file paths
            old_image_path = os.path.join(mat_images_dir, f'{old_image_name}.mat')
            new_image_path = os.path.join(mat_images_dir, f'{new_image_name}.mat')
            gt_image_path = os.path.join(mat_images_dir, f'{gt_image_name}.mat')

            with open(old_image_path, 'wb+') as f:
                for chunk in old_image.chunks():
                    f.write(chunk)

            with open(new_image_path, 'wb+') as f:
                for chunk in new_image.chunks():
                    f.write(chunk)

            with open(gt_image_path, 'wb+') as f:
                for chunk in gt_image.chunks():
                    f.write(chunk)

            # Return a success response
            s=train_model(request)
            predict_image = (os.path.join(settings.MEDIA_ROOT, 'predicted_image.jpeg'))
            print((os.path.join(settings.MEDIA_ROOT, 'gt_image.jpeg')))
            gt_image = (os.path.join(settings.MEDIA_ROOT, 'gt_image.jpeg'))
            # with open(predict_image, 'rb') as f:
            #     predict_image_base64 = base64.b64encode(f.read()).decode('utf-8')
            # with open(gt_image, 'rb') as f:
            #     gt_image_base64 = base64.b64encode(f.read()).decode('utf-8')

            # print(predict_image_base64)
            # print(gt_image_base64)
            response_data = {
                'status': 'success',
                'predicted_image': 'gt_image.jpg',
                'gt_image': 'predicted_image.jpg'
            }
            return JsonResponse(response_data)
        else:
            # Return an error response if any of the files is missing
            return JsonResponse({'status': 'error', 'message': 'All files are required'})
    else:
        # Return an error response if the request method is not POST
        return JsonResponse({'status': 'error', 'message': 'Invalid request method'})


import os
import random
import itertools
from random import shuffle
import h5py
import json
import tensorflow as tf

import numpy as np
import scipy
import scipy.io as sio # Scipy input and output
import scipy.ndimage
from skimage.transform import rotate
import spectral # Module for processing hyperspectral image data.
import matplotlib
# scikit-learn imports
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.metrics import classification_report, confusion_matrix

# keras imports
import keras
from tensorflow.keras import layers
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D, ConvLSTM2D, TimeDistributed
from keras.optimizers import SGD
from keras.models import load_model
from keras import backend as K
from keras.utils import to_categorical

def load_dataset():
    """load dataset parameters from config.json"""
    data_1 = sio.loadmat('C:\\Users\\Hp\Desktop\\adi 123\\adi\\GT\\mat_images\\old_image.mat')
    print('adarsh')
    print(list(data_1.keys()))
    s = list(data_1.keys())[3]  # Assuming there's only one key
    print(s)
    data_1 = data_1[s]
    
    data_2 = sio.loadmat('C:\\Users\\Hp\\Desktop\\adi 123\\adi\GT\\mat_images\\new_image.mat')
    print(list(data_2.keys()))
    s = list(data_2.keys())[3]
    print(s)
    data_2 = data_2[s]
    
    labels = sio.loadmat('C:\\Users\\Hp\\Desktop\\adi 123\\adi\\GT\\mat_images\\gt_image.mat')
    print(list(labels.keys()))
    s = list(labels.keys())[3]
    print(s)
    labels = labels[s]
    print('adarshA')
    
    return data_1, data_2, labels

def apply_pca(X, num_components=75):
    """apply pca to X and return new_X"""

    new_X = np.reshape(X, (-1, X.shape[2]))
    pca = PCA(n_components=num_components, whiten=True)
    new_X = pca.fit_transform(new_X)
    new_X = np.reshape(new_X, (X.shape[0],X.shape[1], num_components))
    return new_X, pca

def pad_with_zeros(X, margin=2):
    """apply zero padding to X with margin"""

    new_X = np.zeros((X.shape[0] + 2 * margin, X.shape[1] + 2* margin, X.shape[2]))
    x_offset = margin
    y_offset = margin
    new_X[x_offset:X.shape[0] + x_offset, y_offset:X.shape[1] + y_offset, :] = X
    return new_X

def create_patches(X, y, window_size=7, remove_zero_labels = True):
    """create patch from image. suppose the image has the shape (w,h,c) then the patch shape is
    (w*h,window_size,window_size,c)"""

    margin = int((window_size - 1) / 2)
    zero_padded_X = pad_with_zeros(X, margin=margin)
    # split patches
    patches_data = np.zeros((X.shape[0] * X.shape[1], window_size, window_size, X.shape[2]))
    patchs_labels = np.zeros((X.shape[0] * X.shape[1]))
    patch_index = 0
    for r in range(margin, zero_padded_X.shape[0] - margin):
        for c in range(margin, zero_padded_X.shape[1] - margin):
            patch = zero_padded_X[r - margin:r + margin + 1, c - margin:c + margin + 1]
            patches_data[patch_index, :, :, :] = patch
            patchs_labels[patch_index] = y[r-margin, c-margin] + 1
            patch_index = patch_index + 1

    if remove_zero_labels:
        patches_data = patches_data[patchs_labels>0,:,:,:]
        patchs_labels = patchs_labels[patchs_labels>0]
        patchs_labels -= 1
    return patches_data, patchs_labels

def split_train_test_set(X, y, test_ratio=0.10):

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_ratio, random_state=345,
                                                        stratify=y)
    return X_train, X_test, y_train, y_test


from sklearn.model_selection import train_test_split

def split_train_validation_test_set(X, y, test_ratio=0.1, validation_ratio=0.1):
    """
    Split the data into training, validation, and test sets.

    Parameters:
        -- X: array-like, shape (n_samples, n_features)
            The feature data.
        -- y: array-like, shape (n_samples,)
            The target labels.
        -- test_ratio: float, optional (default=0.1)
            The proportion of samples to allocate to the test set.
        -- validation_ratio: float, optional (default=0.1)
            The proportion of samples to allocate to the validation set.

    Returns:
        -- X_train: array-like, shape (n_train_samples, n_features)
            The feature data for the training set.
        -- X_val: array-like, shape (n_val_samples, n_features)
            The feature data for the validation set.
        -- X_test: array-like, shape (n_test_samples, n_features)
            The feature data for the test set.
        -- y_train: array-like, shape (n_train_samples,)
            The target labels for the training set.
        -- y_val: array-like, shape (n_val_samples,)
            The target labels for the validation set.
        -- y_test: array-like, shape (n_test_samples,)
            The target labels for the test set.
    """
    # Split the data into training and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_ratio, random_state=345,
                                                        stratify=y)

    # Split the training set into training and validation sets
    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=validation_ratio,
                                                      random_state=345, stratify=y_train)

    return X_train, X_val, X_test, y_train, y_val, y_test

from tensorflow.keras.models import load_model
from tensorflow.keras.initializers import Orthogonal
from tensorflow.keras.models import load_model


custom_initializer = Orthogonal(gain=1.0, seed=None)
model = load_model('C:\\Users\\Hp\\Desktop\\adi 123\\adi\GT\\Std_Unet.h5')
def oversample_weak_classes(X, y):
    """"balance the dataset by prforming oversample of weak classes (making each class have close labels_counts)"""
    unique_labels, labels_counts = np.unique(y, return_counts=True)

    print(unique_labels.shape)
    print(unique_labels)
    print(labels_counts.shape)
    print(labels_counts)
    max_count = np.max(labels_counts)
    labels_inverse_ratios = max_count / labels_counts
    #print(labels_inverse_ratios)
    # repeat for every label and concat
    print(labels_inverse_ratios)
    new_X = X[y == unique_labels[0], :, :, :].repeat(round(labels_inverse_ratios[0]), axis=0)
    new_Y = y[y == unique_labels[0]].repeat(round(labels_inverse_ratios[0]), axis=0)
    for label, labelInverseRatio in zip(unique_labels[1:], labels_inverse_ratios[1:]):
        cX = X[y== label,:,:,:].repeat(round(labelInverseRatio), axis=0)
        cY = y[y == label].repeat(round(labelInverseRatio), axis=0)
        new_X = np.concatenate((new_X, cX))
        new_Y = np.concatenate((new_Y, cY))
    np.random.seed(seed=42)
    rand_perm = np.random.permutation(new_Y.shape[0])
    new_X = new_X[rand_perm, :, :, :]
    new_Y = new_Y[rand_perm]
    unique_labels, labels_counts = np.unique(new_Y, return_counts=True)
    return new_X, new_Y

def augment_data(X_train):
    """augment the data by taking each patch and randomly performing
    a flip(up/down or right/left) or a rotation"""

    for i in range(int(X_train.shape[0]/2)):
        patch = X_train[i,:,:,:]
        num = random.randint(0,2)
        if (num == 0):

            flipped_patch = np.flipud(patch)
        if (num == 1):

            flipped_patch = np.fliplr(patch)
        if (num == 2):

            no = random.randrange(-180,180,30)
            flipped_patch = scipy.ndimage.interpolation.rotate(patch, no,axes=(1, 0),
                                                               reshape=False, output=None, order=3, mode='constant', cval=0.0, prefilter=False)


        patch2 = flipped_patch
        X_train[i,:,:,:] = patch2

    return X_train

def get_patch(data,height_index,width_index):
    #transpose_array = data.transpose((2,0,1))
    #print transpose_array.shape
    height_slice = slice(height_index, height_index+patch_size)
    width_slice = slice(width_index, width_index+patch_size)
    patch = data[height_slice, width_slice, :]

    return patch

def generate_pridected_image(height,width,y,X_2,X):
    """generate the predicted image"""
    outputs = np.zeros((height,width))

    for i in range(height-patch_size+1):
        for j in range(width-patch_size+1):
            target = y[int(i+patch_size/2), int(j+patch_size/2)]
            if target == 0 :
                continue
            else :
                image_patch=get_patch(X,i,j)
                X_test_image = image_patch.reshape(7,7,30).astype('float32')
                image_patch=get_patch(X_2,i,j)
                X_2_test_image = image_patch.reshape(7,7,30).astype('float32')

                X_F = np.array([X_test_image, X_2_test_image])
                X_2_F = X_F.reshape(1,X_F.shape[0],X_F.shape[1],X_F.shape[2],X_F.shape[3])

                prediction = ((model.predict(X_2_F) > 0.5).astype("int32"))
                outputs[int(i+patch_size/2)][int(j+patch_size/2)] = prediction+1
    return outputs.astype(int)
import matplotlib
matplotlib.use('Agg')
from django.conf import settings
window_size = 7
num_pca_components = 30
test_ratio = 0.25
patch_size = window_size
def train_model(request):
    import matplotlib.pyplot as plt
    X_1, X_2,y = load_dataset()
    X_1,pca = apply_pca(X_1,num_pca_components)
    X_2,pca = apply_pca(X_2,num_pca_components)
    height = y.shape[0]
    width = y.shape[1]
    data = np.zeros(shape=(100,2,7,7,30))
    data_1 = np.array([X_1, X_2])
    X = X_1
    print(X_1.shape)

    print(X.ndim)
    outputs=generate_pridected_image(height,width,y,X_2,X)
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    images_dir = os.path.join(base_dir, "images")
    os.makedirs(images_dir, exist_ok=True)
    predict_image = spectral.imshow(classes=outputs.astype(int), figsize=(7, 7))
    plt.savefig(os.path.join(settings.MEDIA_ROOT, 'predicted_image.jpg'),dpi=256)
    fig = plt.gcf()
    plt.close(fig)

    # Save ground truth image
    gt_image = spectral.imshow(classes=y, figsize=(7, 7))
    plt.savefig(os.path.join(settings.MEDIA_ROOT, 'gt_image.jpg'),dpi=256)
    fig = plt.gcf()
    plt.close(fig)
